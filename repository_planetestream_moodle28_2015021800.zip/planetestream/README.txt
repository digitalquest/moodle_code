/**
 * Planet eStream Moodle Repository Plugin
 *
 * @package    repository_planetestream
 * @copyright  2012 Planet eStream
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 */

For installation, configuration and usage instructions, please refer to the Help Documentation within your Planet eStream website.